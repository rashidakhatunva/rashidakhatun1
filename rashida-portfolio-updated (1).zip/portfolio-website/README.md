# Rashida Khatun — Portfolio Website + Admin Panel

A premium, animated, responsive portfolio for **Rashida Khatun**, Virtual Assistant & Administrative Specialist. The original website architecture and visual design are retained: plain HTML/CSS/vanilla JavaScript, GSAP 3.12.5 + ScrollTrigger, one shared renderer, one Netlify Function, and Netlify Blobs for persistent storage.

Open `START-HERE.html` first for beginner-friendly GitHub and Netlify setup instructions.

## Folder layout

```text
portfolio-website/
├── START-HERE.html
├── README.md
└── website/
    ├── admin/                 Admin Panel
    ├── assets/css/             Shared and admin styles
    ├── assets/js/render.js     Shared browser/Node renderer
    ├── assets/js/main.js       Animations, interactions and form
    ├── assets/js/boot.js       Loads saved server content
    ├── assets/img/             Existing bundled artwork
    ├── netlify/functions/api.js
    ├── index.html              Home
    ├── services.html
    ├── portfolio.html          My Work
    ├── about.html
    ├── testimonials.html
    ├── contact.html
    ├── netlify.toml
    └── _redirects
```

## Deployment note

**Import the repository from GitHub into Netlify. Dragging the folder into Netlify does not activate Netlify Functions**, so the admin login, server saves, image storage, contact inbox, and Netlify Blobs will not work from a simple drag-and-drop deploy. In Netlify, import the GitHub repository and use `website` as the base directory if the repository root contains this folder; publish directory is `.` and the build command is empty. Confirm the deployed site is using `website/netlify.toml` and `website/netlify/functions/api.js`.

## Initial admin login

- URL: `https://your-site-name.netlify.app/admin/`
- Username: `admin`
- Initial password: `ChangeMe123!`

Change the initial password immediately after the first sign-in. Anyone with access to the source files can see the initial credentials. The application is designed to refuse normal content saves until the default password is replaced.

## Admin Panel sections

- Dashboard
- Home Page
- My Work
- About Me
- Services
- Testimonials
- Contact Information
- Inbox
- Images / Media
- Theme / Colors
- Website Settings (including logo and favicon image uploads)
- Admin Account

## Content included

- Name: Rashida Khatun
- Profession: Virtual Assistant & Administrative Specialist
- Focus areas: Social Media Management; Content Creation & Canva Design; E-commerce Support; Customer Relationship Management (CRM); Web Research & Administrative Support
- Email: `rashidaofficialbd@gmail.com`
- Direct WhatsApp: `+8801765516378`
- Theme: retained from the supplied website — `#070B1A` background, `#6AA9FF` cyan, `#3B82F6` violet, `#FF7A2F` ember
- Fonts: Space Grotesk and Inter
- Motion: GSAP/ScrollTrigger, reveals, magnetic buttons, spotlight cards, portrait tilt, marquee and custom cursor, as in the supplied project

No client names, testimonials, project outcomes, revenue, or performance statistics have been invented. The My Work page now includes the portfolio screenshots supplied for social media design, content calendars, email workflows, and task-management tools. No client names, testimonials, project outcomes, revenue, or performance statistics have been invented. Testimonials remain empty until genuine feedback is added in the Admin Panel.

## Architecture and security

The original backend, storage mechanism, authentication, session logic, upload handling, routing, and admin interface are retained. The default content object has been changed to Rashida's supplied details and service focus areas; static pages were re-rendered from the shared `assets/js/render.js` renderer to keep their content in sync with those defaults.

The original project documents these protections: scrypt password hashing with per-account salt, constant-time comparison, HMAC-signed `HttpOnly`/`SameSite=Lax`/`Secure` session cookie with expiry, account-change session invalidation, lockout after repeated wrong passwords, session checks on write endpoints, upload extension/signature checks, SVG script rejection, upload size cap, content filtering, output escaping, and redirects that protect function source paths.

## Editing and redeploying

Use the Admin Panel for content changes; saves are stored in Netlify Blobs and survive redeploys. Source-code changes should be committed to GitHub so Netlify can deploy them. After changing the default content in source, static HTML must be rebuilt from the shared renderer, as done for this package.
